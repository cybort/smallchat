import type { Brief, FactSkin, Quad, SpeechBank } from "./script";
import { mentionsPublicScript } from "./script";

function mix(text: string): number {
  let h = 2166136261;
  for (const ch of text) {
    h ^= ch.codePointAt(0) ?? 0;
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function pieces(text: string): string[] {
  const punct = text
    .split(/[，。；、！？,.!?\s]/)
    .map((part) => part.trim())
    .filter((part) => part.length >= 2);
  if (punct.length >= 2) return punct.slice(0, 6);
  const source = punct[0] || text.trim() || "这件";
  const cut: string[] = [];
  let buf = "";
  for (const ch of source) {
    buf += ch;
    if (buf.length >= 2 && /[的把在了是就而又从对给让被到过]/.test(ch) && cut.length < 5) {
      cut.push(buf);
      buf = "";
    }
  }
  if (buf) cut.push(buf);
  const usable = cut.filter((part) => part.length >= 2);
  if (usable.length >= 2) return usable;
  const mid = Math.max(1, Math.floor(source.length / 2));
  return [source.slice(0, mid), source.slice(mid) || source];
}

function windows(text: string): string[] {
  const source = text.replace(/[，。；、！？\s]/g, "");
  const out: string[] = [];
  const base = source || "就事说事";
  for (let n = 2; n <= Math.min(6, base.length); n++) {
    for (let i = 0; i + n <= base.length; i++) out.push(base.slice(i, i + n));
  }
  return out.length ? out : [base];
}

function prefixFree(list: string[]): boolean {
  const sorted = [...list].sort();
  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i].startsWith(sorted[i - 1])) return false;
  }
  return new Set(list).size === list.length && list.every((item) => item.length > 0);
}

function takeDistinct(n: number, at: (tryIndex: number) => string, punct: "，" | "。"): string[] {
  const out: string[] = [];
  let t = 0;
  while (out.length < n) {
    if (t > n * 12) throw new Error("私稿拼不出足够的不同说法");
    const core = at(t).replace(/[，。\s]/g, "");
    t++;
    if (!core) continue;
    const line = `${core}${punct}`;
    if (out.includes(line)) continue;
    if (out.some((have) => have.startsWith(line) || line.startsWith(have))) continue;
    if (mentionsPublicScript(line)) continue;
    out.push(line);
  }
  return out;
}

function rotateTake(n: number, salt: string, items: string[], punct: "，" | "。"): string[] {
  if (items.length < n) throw new Error("私稿太短，写不开");
  const start = mix(salt) % items.length;
  const ordered = items.map((_, i) => items[(i + start) % items.length]);
  return takeDistinct(n, (i) => ordered[i % ordered.length], punct);
}

const STANCES = [
  "照旧", "当场", "顺口", "低声", "就近", "原样", "眼下", "此刻",
  "手里", "灯下", "窗边", "门口", "路上", "桌边", "晨起", "夜里",
  "起身", "坐下", "站着", "停下", "回头", "仅此", "到此", "先放",
  "按下", "记下", "留白", "说开", "短问", "慢说", "直说", "罢了",
];

export function forgeSpeech(brief: Brief, voice: string, author: string, epoch: number, pen = "私稿拼接"): SpeechBank {
  const salt = `${author}|${voice}|${epoch}|${brief.persona}`;
  const bits = windows(brief.persona);
  const openers = rotateTake(
    16,
    `${salt}|open`,
    STANCES.map((stance, i) => `${voice}${stance}提起${bits[i % bits.length]}`),
    "，",
  );
  const moods = rotateTake(
    16,
    `${salt}|mood`,
    STANCES.map((stance, i) => `口气${stance}留在${bits[(i + 3) % bits.length]}`),
    "，",
  );
  const tails = rotateTake(
    16,
    `${salt}|tail`,
    STANCES.map((stance, i) => `${stance}便停在${bits[(i + 5) % bits.length]}`),
    "。",
  );

  const verbs = ["先是", "提到", "仍是", "对着", "留着", "碰到", "说回", "重复", "收在", "只剩", "未改", "重提"];
  const facts: FactSkin[] = brief.facts.map((fact) => {
    const clips = pieces(fact.text).flatMap((part) => [part, part.slice(0, Math.min(6, part.length))]).filter((part) => part.length >= 2);
    const bodies = verbs.flatMap((verb) => clips.map((clip) => `${verb}${fact.anchor}里的${clip}`));
    const skin = (phase: string, slot: "a" | "b"): Quad => {
      if (phase === "bridge" && slot === "a") {
        return asQuad(takeDistinct(4, (i) => ["{here}先收到这", "先把{here}放下", "{here}不再展开", "离开{here}"][i % 4], "，"));
      }
      if (phase === "bridge" && slot === "b") {
        return asQuad(takeDistinct(4, (i) => ["转到{next}", "{next}接上来", "下面改看{next}", "{next}这头"][i % 4], "，"));
      }
      return asQuad(rotateTake(4, `${salt}|${fact.anchor}|${phase}|${slot}`, bodies, "，"));
    };
    return {
      anchor: fact.anchor,
      text: fact.text,
      open: { a: skin("open", "a"), b: skin("open", "b") },
      memory: { a: skin("memory", "a"), b: skin("memory", "b") },
      today: { a: skin("today", "a"), b: skin("today", "b") },
      bridge: { a: skin("bridge", "a"), b: skin("bridge", "b") },
    };
  });

  return { voice, author, epoch, persona: brief.persona, openers, moods, tails, facts, pen };
}

function asQuad(list: string[]): Quad {
  if (list.length !== 4 || !prefixFree(list)) throw new Error("说法没有站稳");
  return list as Quad;
}

export function forgeNotes(brief: Brief, voice: string, author: string, epoch: number, rich: boolean): string[] {
  const salt = `${author}|${voice}|${epoch}`;
  const out: string[] = [];
  let t = 0;
  while (out.length < 16) {
    if (t > 400) throw new Error("附言拼不够");
    const fact = brief.facts[(t + epoch) % brief.facts.length];
    const bits = pieces(fact.text).join("");
    const start = (t * 2 + mix(salt)) % Math.max(1, bits.length - 4);
    const clip = bits.slice(start, start + 8 + (t % 5)) || fact.text.slice(0, 8);
    const form = t % (rich ? 6 : 2);
    let note = "";
    if (!rich || form === 0) note = `${fact.anchor}:${clip}`;
    else if (form === 1) note = `${fact.anchor}/${clip}`;
    else if (form === 2) note = `${voice}:${fact.anchor}:${clip}`;
    else if (form === 3) note = `${fact.anchor} ${clip}`;
    else if (form === 4) note = `${clip}→${fact.anchor}`;
    else note = `${fact.anchor}#${clip}`;
    t++;
    note = note.replace(/[\n\r"]/g, "").slice(0, 48);
    if (!note || out.includes(note)) continue;
    out.push(note);
  }
  const lens = out.map((note) => note.length);
  const min = Math.min(...lens);
  const max = Math.max(...lens);
  if (max > min * 3) throw new Error("附言长短差得太大");
  return out;
}

type RemoteShape = {
  openers?: unknown;
  moods?: unknown;
  tails?: unknown;
  facts?: unknown;
};

function quadOf(value: unknown, label: string, punct: "，" | "。"): Quad {
  if (!Array.isArray(value) || value.length !== 4) throw new Error(`${label}需要四条`);
  const list = value.map((item, i) => stringItem(item, `${label}${i}`, punct));
  if (!prefixFree(list)) throw new Error(`${label}里有彼此遮住的句子`);
  return list as Quad;
}

function stringItem(value: unknown, label: string, punct: "，" | "。"): string {
  if (typeof value !== "string") throw new Error(`${label}不是句子`);
  const text = value.trim().replace(/\s+/g, "");
  if (!text.endsWith(punct)) throw new Error(`${label}要以${punct}收束`);
  if (mentionsPublicScript(text)) throw new Error(`${label}撞上了公开话题表`);
  return text;
}

function sixteen(value: unknown, label: string, punct: "，" | "。"): string[] {
  if (!Array.isArray(value) || value.length !== 16) throw new Error(`${label}需要十六条`);
  const list = value.map((item, i) => stringItem(item, `${label}${i}`, punct));
  if (!prefixFree(list)) throw new Error(`${label}里有彼此遮住的句子`);
  return list;
}

export function parseRemoteSpeech(raw: string, brief: Brief, voice: string, author: string, epoch: number): SpeechBank {
  const trimmed = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/g, "").trim();
  let parsed: RemoteShape;
  try {
    parsed = JSON.parse(trimmed) as RemoteShape;
  } catch {
    throw new Error("模型没有返回成稿");
  }
  const openers = sixteen(parsed.openers, "起句", "，");
  const moods = sixteen(parsed.moods, "口气", "，");
  const tails = sixteen(parsed.tails, "收句", "。");
  const rows = parsed.facts;
  if (!Array.isArray(rows) || rows.length !== brief.facts.length) {
    throw new Error("模型改动了事实的件数");
  }
  const facts: FactSkin[] = brief.facts.map((fact, index) => {
    const got = rows[index] as { open?: { a?: unknown; b?: unknown }; memory?: { a?: unknown; b?: unknown }; today?: { a?: unknown; b?: unknown }; bridge?: { a?: unknown; b?: unknown } } | undefined;
    const phase = (name: "open" | "memory" | "today" | "bridge", slot: "a" | "b"): Quad => {
      const list = quadOf(got?.[name]?.[slot], `${fact.anchor}${name}${slot}`, "，");
      if (name === "bridge" && slot === "a" && list.some((item) => !item.includes("{here}"))) {
        throw new Error("转折要留住这一件的锚点");
      }
      if (name === "bridge" && slot === "b" && list.some((item) => !item.includes("{next}"))) {
        throw new Error("转折要指向下一件");
      }
      if (name !== "bridge" && list.some((item) => !item.includes(fact.anchor))) {
        throw new Error("句子离开了这一件事实");
      }
      return list;
    };
    return {
      anchor: fact.anchor,
      text: fact.text,
      open: { a: phase("open", "a"), b: phase("open", "b") },
      memory: { a: phase("memory", "a"), b: phase("memory", "b") },
      today: { a: phase("today", "a"), b: phase("today", "b") },
      bridge: { a: phase("bridge", "a"), b: phase("bridge", "b") },
    };
  });
  return { voice, author, epoch, persona: brief.persona, openers, moods, tails, facts, pen: "本地模型" };
}

export function parseRemoteNotes(raw: string): string[] {
  const trimmed = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/g, "").trim();
  let parsed: unknown;
  try {
    parsed = JSON.parse(trimmed);
  } catch {
    throw new Error("模型没有返回附言");
  }
  const list = Array.isArray(parsed) ? parsed : (parsed as { notes?: unknown }).notes;
  if (!Array.isArray(list) || list.length !== 16) throw new Error("附言要十六条");
  const notes = list.map((item, i) => {
    if (typeof item !== "string") throw new Error(`附言${i}不是文字`);
    const note = item.replace(/[\n\r"]/g, "").trim();
    if (!note || note.length > 48) throw new Error(`附言${i}太长或是空的`);
    return note;
  });
  if (new Set(notes).size !== 16) throw new Error("附言有重复");
  return notes;
}

async function complete(url: string, model: string, system: string, user: string): Promise<string> {
  const response = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      model,
      temperature: 0.4,
      stream: false,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
    signal: AbortSignal.timeout(25000),
  });
  if (!response.ok) throw new Error(`本地模型回应 ${response.status}`);
  const body = (await response.json()) as { choices?: { message?: { content?: string } }[]; message?: { content?: string }; response?: string };
  const text = body.choices?.[0]?.message?.content ?? body.message?.content ?? body.response ?? "";
  if (!text.trim()) throw new Error("本地模型没有写出内容");
  return text;
}

const SPEECH_SYSTEM =
  "你在上线前为一份私稿写表面说法。只输出 JSON，不要解释。句子必须使用私稿里的词，不要写成通用闲聊套话。列表里的句子不能彼此作为前缀。";

export async function forgeSpeechRemote(
  url: string,
  model: string,
  brief: Brief,
  voice: string,
  author: string,
  epoch: number,
): Promise<SpeechBank> {
  const facts = brief.facts.map((fact) => `${fact.anchor}｜${fact.text}`).join("\n");
  const user = `纪元 ${epoch}，作者 ${author}，口气 ${voice}。
人设：${brief.persona}
事实：
${facts}

返回一个 JSON 对象，键为 openers、moods、tails、facts。
openers 十六条，每条以逗号结尾。
moods 十六条，每条以逗号结尾。
tails 十六条，每条以句号结尾。
facts 与上面的事实等长、同序。每件含 open、memory、today、bridge，各自有 a、b 两个数组，每个数组四条，以逗号结尾。
open、memory、today 的每条都要含该件锚点。
bridge.a 的每条含 {here}，bridge.b 的每条含 {next}，这两个记号原样保留。`;
  const text = await complete(url, model, SPEECH_SYSTEM, user);
  return parseRemoteSpeech(text, brief, voice, author, epoch);
}

export async function forgeNotesRemote(
  url: string,
  model: string,
  brief: Brief,
  voice: string,
  author: string,
  epoch: number,
): Promise<string[]> {
  const facts = brief.facts.map((fact) => `${fact.anchor}｜${fact.text}`).join("\n");
  const user = `纪元 ${epoch}，作者 ${author}，口气 ${voice}。
人设：${brief.persona}
事实：
${facts}

只输出 JSON 字符串数组，十六条。每条是程序附言，短，不含换行和引号，长度彼此接近，意思来自这些事实，十六条彼此不同。不要解释。`;
  const text = await complete(
    url,
    model,
    "你在给一个已经定好字段的程序写附言。不要改字段名，不要输出对象，只输出十六条字符串的 JSON 数组。",
    user,
  );
  return parseRemoteNotes(text);
}
