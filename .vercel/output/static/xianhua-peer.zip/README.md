# 闲话

两端各跑一份。控制口和数据口分开。没有成稿时，线上是程序里自带的中文闲聊。有成稿时，两口都改用那份私稿，程序里的话题表对不上。

需要 Node.js 22 或更新。

```
npm install
node --experimental-transform-types --import ./register.mjs src/bin/xianhua.ts keygen 甲 id-a.json
node --experimental-transform-types --import ./register.mjs src/bin/xianhua.ts keygen 乙 id-b.json
```

把 `id-a.json.pub` 交给乙，把 `id-b.json.pub` 交给甲。私钥留在自己机器上。

私稿写成文本，第一行是口气，后面每行是「锚点｜事实」：

```
人设：说话短，先摆事实，不抒情。
草稿｜周三把窗口的草稿寄出
面馆｜巷口那家只在雨天去
```

离线冻一版，两边用同一份。`--dialect speech` 是闲聊，`program` 是程序请求和响应。`--posture both` 表示两端各写自己的出站，`one` 表示一端写两边。模型若要参与，只在这一步之前写句子，不要在线上调用。

```
node --experimental-transform-types --import ./register.mjs src/bin/xianhua.ts mint \
  --brief 私稿.txt --epoch 3 --posture both --dialect speech --out surface.json
```

留下的那一端：

```
node --experimental-transform-types --import ./register.mjs src/bin/xianhua.ts serve \
  --identity id-a.json --peer id-b.json.pub \
  --control 4711 --data 4712 --profile talk --surface surface.json
```

出去的那一端：

```
node --experimental-transform-types --import ./register.mjs src/bin/xianhua.ts connect \
  --identity id-b.json --peer id-a.json.pub --host <甲的地址> \
  --control 4711 --data 4712 --profile talk --surface surface.json \
  --socks 1080 --http 8088 --map 15432=10.0.0.8:5432
```

`--profile` 用 `talk` 或 `dense`，只在没带 `--surface` 时决定数据口的公开档位，两边要一致。带了成稿以后，数据口和控制口都走成稿。`--map` 可以写多次。代理是 SOCKS5，HTTP 口只接受 CONNECT。

换纪元就重新 mint，把新的 `surface.json` 再交一次。同一纪元用久了，句子会循环。
