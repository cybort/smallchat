import { register } from "node:module";
import { pathToFileURL } from "node:url";

register("./register-hooks.mjs", { parentURL: pathToFileURL(import.meta.filename ?? import.meta.url) });
