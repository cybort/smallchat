import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";

export async function resolve(specifier, context, nextResolve) {
  if (specifier.startsWith(".")) {
    const candidates = [specifier, `${specifier}.ts`, `${specifier}.tsx`, `${specifier}.js`];
    for (const candidate of candidates) {
      let url;
      try {
        url = new URL(candidate, context.parentURL);
      } catch {
        continue;
      }
      if (url.protocol === "file:" && existsSync(fileURLToPath(url))) {
        return nextResolve(url.href, context);
      }
    }
  }
  return nextResolve(specifier, context);
}
